int Periodic_int(int a, int A);

double Periodic(double x, double X);

double Shortest(double v, double X_2, double X);
